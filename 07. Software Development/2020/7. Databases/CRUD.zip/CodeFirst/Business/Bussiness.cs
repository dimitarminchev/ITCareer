﻿using System.Linq;
using System.Collections.Generic;

public class Bussiness
{
    private Context context;

    /// <summary>
    /// Create
    /// </summary>
    public void Create(Product product)
    {
        using (context = new Context())
        {
            context.Products.Add(product);
            context.SaveChanges();
        }
    }

    /// <summary>
    /// Read
    /// </summary>
    public List<Product> Read()
    {
        using (context = new Context())
        {
            return context.Products.ToList();
        }
    }

    /// <summary>
    /// Update Product
    /// </summary>
    public void Update(Product product)
    {
        using (context = new Context())
        {
            var item = context.Products.Find(product.Id);
            if (item != null)
            {
                context.Entry(item).CurrentValues.SetValues(product);
                context.SaveChanges();
            }
        }
    }

    /// <summary>
    ///  Delete Product
    /// </summary>
    public void Delete(int id)
    {
        using (context = new Context())
        {
            var product = context.Products.Find(id);
            if (product != null)
            {
                context.Products.Remove(product);
                context.SaveChanges();
            }
        }
    }

    /// <summary>
    ///  Get
    /// </summary>
    public Product Get(int id)
    {
        using (context = new Context())
        {
            return context.Products.Find(id);
        }
    }
}
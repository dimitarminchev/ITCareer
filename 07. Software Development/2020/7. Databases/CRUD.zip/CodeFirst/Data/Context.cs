﻿using Microsoft.EntityFrameworkCore;

public class Context : DbContext
{
    public DbSet<Product> Products { get; set; }

    public Context()
    {
        Database.EnsureCreated();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB.;Database=shop; Integrated Security=True");
    }
}
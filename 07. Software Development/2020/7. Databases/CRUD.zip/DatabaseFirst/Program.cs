﻿namespace DatabaseFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            var display = new Presentation();
        }
    }
}

﻿using System;
using System.Linq;

public class Presentation
{
    // Business Logic
    private Bussiness business = new Bussiness();

    /// <summary>
    /// Constructor
    /// </summary>
    public Presentation()
    {
        while (true)
        {
            // Input Command
            var color = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("[C]reate, [R]ead , [U]pdate, [D]elete: ");
            Console.ForegroundColor = color;
            var key = Console.ReadKey().Key.ToString();
            Console.WriteLine();

            // Execute Command
            switch (key)
            {
                case "C": Create(); break;
                case "R": Read(); break;
                case "U": Update(); break;
                case "D": Delete(); break;
                default: return;
            }
        }
    }

    /// <summary>
    ///  Create
    /// </summary>
    public void Create()
    {
        Product product = new Product();
        Console.Write("Name: ");
        product.Name = Console.ReadLine();
        Console.Write("Price: ");
        product.Price = decimal.Parse(Console.ReadLine());
        Console.Write("Stock: ");
        product.Stock = int.Parse(Console.ReadLine());
        business.Create(product);
        Console.WriteLine("Created!");
    }

    /// <summary>
    /// Read
    /// </summary>
    public void Read()
    {
        var products = business.Read();
        if (products.Count() == 0)
        {
            Console.WriteLine("Empty!");
        }
        else
        {
            Console.WriteLine(new string('-', 25));
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id} {item.Name} {item.Price}$ {item.Stock}");
            }
            Console.WriteLine(new string('-', 25));
        }
    }

    /// <summary>
    /// Update
    /// </summary>
    private void Update()
    {
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());
        Product product = business.Get(id);
        if (product != null)
        {
            Console.Write("Name: ");
            product.Name = Console.ReadLine();
            Console.Write("Price: ");
            product.Price = decimal.Parse(Console.ReadLine());
            Console.Write("Stock: ");
            product.Stock = int.Parse(Console.ReadLine());
            business.Update(product);
            Console.WriteLine("Updated!");
        }
        else
        {
            Console.WriteLine("Not found!");
        }
    }

    /// <summary>
    ///  Delete
    /// </summary>
    public void Delete()
    {
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());
        if (business.Delete(id))
        {
            Console.WriteLine("Deleted!");
        }
        else
        {
            Console.WriteLine("Not found!");
        }
    }
}
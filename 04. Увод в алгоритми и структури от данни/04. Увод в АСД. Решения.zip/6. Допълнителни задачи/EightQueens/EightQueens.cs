﻿namespace EightQueens
{
    public static class EightQueens
    {
        public const int Size = 8;
        public static bool[,] chessboard = new bool[Size, Size];
    }
}
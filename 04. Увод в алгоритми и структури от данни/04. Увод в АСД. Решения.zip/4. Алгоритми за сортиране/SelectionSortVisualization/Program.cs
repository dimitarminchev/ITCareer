﻿namespace SelectionSortVisualization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // TODO
        }
    }
}
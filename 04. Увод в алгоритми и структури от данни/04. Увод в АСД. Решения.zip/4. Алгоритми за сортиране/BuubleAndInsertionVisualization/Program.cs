﻿namespace BuubleAndInsertionVisualization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // TODO
        }
    }
}
# PetFeeder
A simulation of an arduino pet feeder


## For the online simulation use the following link:
https://www.tinkercad.com/things/fS1IKWCbUnP

Process:
1. Coming up with the idea

2. Making a list of the needed components

3. Figuring out how to work with Tinkercad

4. Code


﻿namespace Eventures.Data
{
    public static class GlobalConstants
    {
        public const string AdminRoleName = "Administrator";
    }
}

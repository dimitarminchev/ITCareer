﻿namespace Eventures.Data
{
    public interface IMapWith<TModel>
    {
        // nope
    }
}

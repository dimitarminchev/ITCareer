﻿using System;

namespace Data
{
    public class Car
    {
        public int Id { get; set; }

        public string RegNo { get; set; }

        public string Model { get; set; }

        public string Brand { get; set; }
    }
}

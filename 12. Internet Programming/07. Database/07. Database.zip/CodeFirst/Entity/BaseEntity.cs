﻿namespace CodeFirst.Entity
{
    public abstract class BaseEntity
    {
        public int Id { get; set; }
    }
}

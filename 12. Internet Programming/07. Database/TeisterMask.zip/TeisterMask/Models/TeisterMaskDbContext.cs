﻿using Microsoft.EntityFrameworkCore;


namespace TeisterMask.Models
{
    public class TeisterMaskDbContext : DbContext
    {
        // Constructors
        public TeisterMaskDbContext()
        {
            ;;
        }
        public TeisterMaskDbContext(DbContextOptions<TeisterMaskDbContext> options) : base(options)
        {
            ;;
        }

        // Tables
        public virtual DbSet<Task> Tasks { get; set; }

        // Connection String
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog=TasksDB");
        }
    }
}
﻿namespace Data.Enumeration
{
    public enum EngineEnum
    {
        Diesel,
        Petrol,
        Hybrid,
        Electric
    }
}

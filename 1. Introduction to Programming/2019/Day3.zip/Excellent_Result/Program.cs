﻿using System;
namespace Excellent_Result
{
    class Program
    {
        // 01. Отличен резултат 
        static void Main(string[] args)
        {
            var grade = double.Parse(Console.ReadLine());
            if (grade >= 5.50)
            {
                Console.WriteLine("Excellent!");
            }            
        }
    }
}

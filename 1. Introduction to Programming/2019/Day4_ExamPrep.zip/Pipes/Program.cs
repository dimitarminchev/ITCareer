﻿using System;
namespace Pipes
{
    class Program
    {
        // 2. Тръби в басейн
        static void Main(string[] args)
        {
            var V = int.Parse(Console.ReadLine());
            var T1 = int.Parse(Console.ReadLine());
            var T2 = int.Parse(Console.ReadLine());
            var H = double.Parse(Console.ReadLine());

            double St = H * (T1 + T2);
            double P = (St * 100) / V;
            double PT1 = Math.Floor(T1 * H * 100 / St);
            double PT2 = Math.Floor(T2 * H * 100 / St);

            if (V > St)
            {
                Console.WriteLine("The pool is {0}% full. Pipe 1: {1}%. Pipe 2: {2}%", P, PT1, PT2);
            }
            else
            {
                Console.WriteLine("For {0} hours the pool overflows with {1} litters", H, St - V);
            }
        }
    }
}

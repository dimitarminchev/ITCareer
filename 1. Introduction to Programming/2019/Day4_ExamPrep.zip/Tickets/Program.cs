﻿using System;
namespace Tickets
{
    class Program
    {
        // 8. Билети за мач
        static void Main(string[] args)
        {

        }
    }
}

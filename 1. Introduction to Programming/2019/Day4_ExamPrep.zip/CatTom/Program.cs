﻿using System;
namespace CatTom
{
    class Program
    {
        // 3. Поспаливата котка Том
        static void Main(string[] args)
        {

        }
    }
}

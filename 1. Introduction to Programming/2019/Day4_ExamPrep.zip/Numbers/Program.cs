﻿using System;
namespace Numbers
{
    class Program
    {
        // 7. Операции между числа
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var b = double.Parse(Console.ReadLine());
            var sign = Console.ReadLine();
            switch (sign)
            {
                case "+": Console.Write("{0} + {1} = {2}",a, b, a + b);
                    if ((a + b) % 2 == 0) Console.WriteLine("even");
                    else Console.WriteLine("odd"); break;
                case "*":
                    Console.Write("{0} * {1} = {2}",a, b, a * b);
                    if ((a * b) % 2 == 0) Console.WriteLine("even");
                    else Console.WriteLine("odd"); break;
                case "-":
                    Console.Write("{0} - {1} = {2}",a, b, a - b);
                    if ((a - b) % 2 == 0) Console.WriteLine("even");
                    else Console.WriteLine("odd"); break;
                case "/":
                    Console.Write("{0} / {1} = {2}", a, b, a / b); break;
                case "%":
                    Console.Write("{0} % {1} = {2}", a, b, a % b); break;
            }
        }
    }
}

﻿using System;
namespace Transport
{
    class Program
    {
        // 1. Цена за транспорт
        static void Main(string[] args)
        {

        }
    }
}

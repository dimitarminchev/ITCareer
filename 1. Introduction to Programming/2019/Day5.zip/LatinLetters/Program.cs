﻿using System;
namespace LatinLetters
{
    class Program
    {
        // 3. Всички латински букви
        static void Main(string[] args)
        {
            for (var letter = 'a'; letter <= 'z'; letter++)
            {
                Console.Write(letter + " ");
            }
            Console.WriteLine();
        }
    }
}

﻿using System;
namespace Numbers1to100
{
    class Program
    {
        // 1. Отпечатваме числата от 1 до 100
        static void Main(string[] args)
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine("i=" + i);                
            }
        }
    }
}

﻿using System;
namespace SquareFrame
{
    class Program
    {
        // 15. Квадратна рамка
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());

            // v1 (Bug) 
            Console.WriteLine("+ " + new string('-', n - 2) + "+");
            for (int i = 0; i < n-2; i++)
            Console.WriteLine("|" + new string('-', n - 2) + "|");
            Console.WriteLine("+ " + new string('-', n - 2) + "+");

            // v2
            // Top
            Console.Write("+");
            for (int i = 0; i < n - 2; i++) Console.Write(" -");
            Console.WriteLine(" +");
            // Middle
            for (int row = 0; row < n - 2; row++)
            {
                Console.Write("|");
                for (int i = 0; i < n - 2; i++) Console.Write(" -");
                Console.WriteLine(" |");
            }
            // Bottom
            Console.Write("+");
            for (int i = 0; i < n - 2; i++) Console.Write(" -");
            Console.WriteLine(" +");
        }
    }
}

﻿using System;
namespace Convert_USD_BGN
{
    class Program
    {
        // 7. Конвертор от USD към BGN
        static void Main(string[] args)
        {
            var usd = double.Parse(Console.ReadLine());
            var bgn = usd * 1.79549;
            Console.WriteLine("{0:f2} BGN",bgn);
        }
    }
}

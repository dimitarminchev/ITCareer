﻿using System;
namespace Convert_Money
{
    class Program
    {
        // 12. Междувалутен конвертор
        static void Main(string[] args)
        {
            var VAL = double.Parse(Console.ReadLine());
            var C1 = Console.ReadLine();
            var C2 = Console.ReadLine();
            switch (C1)
            {
                case "USD": VAL *= 1.79549; break;
                case "EUR": VAL *= 1.95583; break;
                case "GBP": VAL *= 2.53405; break;
            }
            switch (C2)
            {
                case "USD": VAL /= 1.79549; break;
                case "EUR": VAL /= 1.95583; break;
                case "GBP": VAL /= 2.53405; break;
            }
            Console.WriteLine("{0:f2}", VAL);
        }
    }
}

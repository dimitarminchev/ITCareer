﻿using System;
namespace Convert_Rad_Deg
{
    class Program
    {
        // 6. Конвертор от радиани в градуси
        static void Main(string[] args)
        {
            var rad = double.Parse(Console.ReadLine());
            var deg = Math.Round((180 / Math.PI) * rad);
            Console.WriteLine(deg);
        }
    }
}

﻿using System;
namespace Triangle_Area
{
    class Program
    {
        // 11. Лице на триъгълник
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var h = double.Parse(Console.ReadLine());
            var area = Math.Round(a * h / 2,2);
            Console.WriteLine("Triangle area = " + area);
        }
    }
}

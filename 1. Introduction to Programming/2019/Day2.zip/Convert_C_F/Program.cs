﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convert_C_F
{
    class Program
    {
        // 5. Конвертор от Целзии към Фаренхайт
        static void Main(string[] args)
        {
            // Въвеждаме градусите в Целзии като число с плаваща запетая
            var C = double.Parse(Console.ReadLine());

            // Конвериране на градусите целзии в градуси фаренхайт
            var F = C * 1.8 + 32;

            // Извеждане на получения резултат
            Console.WriteLine(F);
        }
    }
}

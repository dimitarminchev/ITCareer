﻿using System;
namespace _1000_Days
{
    class Program
    {
        // 13. 1000 дни на Земята
        static void Main(string[] args)
        {
            // Въвеждаме дата
            var day = DateTime.ParseExact(Console.ReadLine(),"dd-MM-yyyy",null);

            // Добавяме 999 дни към въведената дата
            day = day.AddDays(999);

            // Отпечатваме новата дата
            Console.WriteLine(day.ToString("dd-MM-yyyy"));
        }
    }
}

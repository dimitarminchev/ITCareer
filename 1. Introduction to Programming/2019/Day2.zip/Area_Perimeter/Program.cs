﻿using System;
namespace Area_Perimeter
{
    class Program
    {
        // 9. Периметър и лице на кръг
        static void Main(string[] args)
        {
            var r = double.Parse(Console.ReadLine());
            var area = Math.Round(Math.PI * r * r, 2);
            var perimeter = Math.Round(2 * Math.PI * r, 2);
            Console.WriteLine("Area = {0}", area);
            Console.WriteLine("Perimeter = {0}", perimeter);
        }
    }
}

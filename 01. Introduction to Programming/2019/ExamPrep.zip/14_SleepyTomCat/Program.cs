﻿using System;
namespace _14_SleepyTomCat
{
    class Program
    {
        // 14. Sleepy Tom Cat
        static void Main(string[] args)
        {
            var vacation = int.Parse(Console.ReadLine());
            var workdays = 365 - vacation;
            var norma = (vacation * 127) + (workdays * 63);
            if (30000 - norma > 0)
            {
                Console.WriteLine("Tom sleeps well");
                Console.WriteLine("{0} hours and {1} minutes less for play",
                    (30000 - norma) / 60, (30000-norma) % 60);
            }
            else
            {
                Console.WriteLine("Tom will run away");
                Console.WriteLine("{0} hours and {1} minutes more for play",
                    (norma - 30000) / 60, (norma - 30000) % 60);
            }
        }
    }
}

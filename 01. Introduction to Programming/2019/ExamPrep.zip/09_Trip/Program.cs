﻿using System;
namespace _09_Trip
{
    class Program
    {
        // 09. Trip
        static void Main(string[] args)
        {
            var bd = double.Parse(Console.ReadLine());
            var s = Console.ReadLine();
            if(bd<=100)
            {
                Console.WriteLine("Somewhere in Bulgaria");
                if(s=="summer") Console.WriteLine("Camp - {0:f2}",bd*0.3);
                else Console.WriteLine("Hotel - {0:f2}",bd*0.7);
            }
            else if (bd <= 1000)
            {
                Console.WriteLine("Somewhere in Balkans");
                if (s == "summer") Console.WriteLine("Camp - {0:f2}", bd * 0.4);
                else Console.WriteLine("Hotel - {0:f2}", bd * 0.8);
            }
            else
            {
                Console.WriteLine("Somewhere in Europe");
                Console.WriteLine("Hotel - {0:f2}",bd*0.9);
            }
        }
    }
}

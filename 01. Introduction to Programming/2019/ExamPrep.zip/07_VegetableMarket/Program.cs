﻿using System;
namespace _07_VegetableMarket
{
    class Program
    {
        // 07. Vegetable Market
        static void Main(string[] args)
        {
            var n = double.Parse(Console.ReadLine());
            var m = double.Parse(Console.ReadLine());
            var kn = int.Parse(Console.ReadLine());
            var km = int.Parse(Console.ReadLine());
            n = n * kn;
            m = m * km;
            n = n + m;
            n = n / 1.94;
            Console.WriteLine(n);
        }
    }
}

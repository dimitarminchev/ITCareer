﻿using System;
namespace _03_OnTimeForTheExam
{
    class Program
    {
        // 03_OnTimeForTheExam
        static void Main(string[] args)
        {
            int h = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int hArrived = int.Parse(Console.ReadLine());
            int mArrived = int.Parse(Console.ReadLine());
            DateTime time = DateTime.Parse(h + ":" + m);
            DateTime timeArrived = DateTime.Parse(hArrived + ":" + mArrived);
            DateTime difference;
            if (time.TimeOfDay < timeArrived.TimeOfDay)
            {
                difference = timeArrived;
                difference = difference.AddHours(-h);
                difference = difference.AddMinutes(-m);
                Console.WriteLine("Late");
                if (difference.ToString("hh") != "12")
                    Console.WriteLine("{0} hours after the start", difference.ToString("h:mm"));
                else
                    Console.WriteLine("{0} minutes after the start", int.Parse(difference.ToString("mm")));
            }
            else if (time.TimeOfDay == timeArrived.TimeOfDay) Console.WriteLine("On time");
            else if(timeArrived.AddMinutes(30)>=time)
            {
                difference = time;
                difference = difference.AddHours(-hArrived);
                difference = difference.AddMinutes(-mArrived);
                Console.WriteLine("Early");
                if (difference.ToString("hh") != "12")
                    Console.WriteLine("{0} hours before the start", difference.ToString("h:mm"));
                else
                    Console.WriteLine("{0} minutes before the start", int.Parse(difference.ToString("mm")));
            }
        }
    }
}

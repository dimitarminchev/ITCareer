﻿using System;
namespace _02_TransportPrice
{
    class Program
    {
        // 02_TransportPrice 
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var dayornight = (Console.ReadLine());
            var price = 0.0;

            if (n < 20 && dayornight == "day") price = 0.70 + (n * 0.79);
            if (n < 20 && dayornight == "night") price = 0.70 + (n * 0.90);
            if (n >= 20 && n < 100) price = n * 0.09;
            if (n >= 100) price = n * 0.06;

            Console.WriteLine("{0}", price);
        }
    }
}

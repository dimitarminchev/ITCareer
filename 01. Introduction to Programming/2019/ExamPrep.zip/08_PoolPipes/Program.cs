﻿using System;
namespace _08_PoolPipes
{
    class Program
    {
        // 08. Pool Pipes
        static void Main(string[] args)
        {
            var V = int.Parse(Console.ReadLine());
            var P1 = int.Parse(Console.ReadLine());
            var P2 = int.Parse(Console.ReadLine());
            var H = double.Parse(Console.ReadLine());

            var v1 = P1 * H;
            var v2 = P2 * H;
            var x = v1 + v2;
            var p1 = v1 / x * 100;
            var p2 = v2 / x * 100;

            if (x <= V)
                Console.WriteLine("The pool is {0}% full. Pipe 1: {1}%. Pipe 2: {2}%.", 
                                   Math.Floor(x/V*100.00), Math.Floor(p1), Math.Floor(p2));
            else
                Console.WriteLine("For {0} hours the pool overflows with {1} liters.", H, Math.Abs(x-V));

        }
    }
}

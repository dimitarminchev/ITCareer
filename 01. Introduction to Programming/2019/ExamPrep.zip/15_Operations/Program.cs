﻿using System;
namespace _15_Operations
{
    class Program
    {
        // 15. Operations
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var b = double.Parse(Console.ReadLine());
            var znak = Console.ReadLine();
            switch (znak)
            {
                case "+":
                    {
                        Console.WriteLine("{0} + {1} = {2} -", a, b, a + b);
                        if ((a + b) % 2 == 0) Console.WriteLine("even");
                        else Console.WriteLine("odd");
                        break;
                    } 
                case "-":
                    {
                        Console.WriteLine("{0} - {1} = {2} -", a, b, a - b);
                        if ((a + b) % 2 == 0) Console.WriteLine("even");
                        else Console.WriteLine("odd");
                        break;
                    }                    
                case "*":
                    {
                        Console.WriteLine("{0} * {1} = {2} -", a, b, a * b);
                        if ((a + b) % 2 == 0) Console.WriteLine("even");
                        else Console.WriteLine("odd");
                        break;
                    }                   
                case "/":
                    {
                        if (b != 0) Console.WriteLine("{0} / {1} = {2} -", a, b, a / b);
                        else Console.WriteLine("Cannot divide {0} by zero",a);
                        break;
                    }
                    
                case "%":
                    {
                        if (b != 0)  Console.WriteLine("{0} % {1} = {2} -", a, b, a % b);
                        else Console.WriteLine("Cannot divide {0} by zero",a);
                        break;
                    }     
            }

        }
    }
}

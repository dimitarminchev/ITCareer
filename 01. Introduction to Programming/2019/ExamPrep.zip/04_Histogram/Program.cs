﻿using System;
namespace _04_Histogram
{
    class Program
    {
        // 04_Histogram
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            double p1 = 0, p2 = 0, p3 = 0, p4 = 0, p5 = 0;
            for (int i = 0; i <n; i++)
            {
                var a = int.Parse(Console.ReadLine());
                if (a < 200) p1++;
                if (a >199 && a< 400) p2++;
                if (a >=400 && a <600) p3++;
                if (a >= 600 && a <800) p4++;
                if (a > 800) p5++;

            }
            Console.WriteLine("{0:f2}%", p1 / n * 100);
            Console.WriteLine("{0:f2}%", p2 / n * 100);
            Console.WriteLine("{0:f2}%", p3 / n * 100);
            Console.WriteLine("{0:f2}%", p4 / n * 100);
            Console.WriteLine("{0:f2}%", p5 / n * 100);
        }
    }
}

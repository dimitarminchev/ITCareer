﻿using System;
namespace _13_RepairingTheTiles
{
    class Program
    {
        // 13. Repairing The Tiles
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double wTile = double.Parse(Console.ReadLine());
            double hTile = double.Parse(Console.ReadLine());
            double wBench = double.Parse(Console.ReadLine());
            double hBench = double.Parse(Console.ReadLine());

            double num = ((n * n) - (wBench * hBench)) / (wTile * hTile);
            double time = num * 0.2;

            Console.WriteLine(num);
            Console.WriteLine(time);
        }
    }
}

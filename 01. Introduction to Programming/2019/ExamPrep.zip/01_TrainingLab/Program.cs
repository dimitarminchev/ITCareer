﻿using System;
namespace _01_TrainingLab
{
    class Program
    {
        // 01. TrainingLab 
        static void Main(string[] args)
        {
            var h = double.Parse(Console.ReadLine());
            var w = double.Parse(Console.ReadLine());
            var Hcm = h * 100;
            var Wcm = w * 100;

            var row = Hcm / 120;
            var RowRound = Math.Floor(row);

            var column = (Wcm - 100) / 70;
            var ColumnRound = Math.Floor(column);

            var seats = (RowRound * ColumnRound);
            Console.WriteLine(seats - 3);
        }
    }
}

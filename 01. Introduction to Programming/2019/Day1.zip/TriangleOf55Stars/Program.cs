﻿using System;
namespace TriangleOf55Stars
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*");
            Console.WriteLine("**");
            Console.WriteLine("***");
            Console.WriteLine("****");
            Console.WriteLine("*****");
            Console.WriteLine("******");
            Console.WriteLine("*******");
            Console.WriteLine("********");
            Console.WriteLine("*********");
            Console.WriteLine("**********");
        }
    }
}

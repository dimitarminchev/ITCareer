﻿using System;

namespace RectangleSquare
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = decimal.Parse(Console.ReadLine());
            var b = decimal.Parse(Console.ReadLine());

            // Лице на правоъгълник
            var s = a * b;
            Console.WriteLine(s);

        }
    }
}

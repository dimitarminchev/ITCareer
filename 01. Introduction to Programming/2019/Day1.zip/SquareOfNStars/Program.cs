﻿using System;
namespace SquareOfNStars
{
    class Program
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());

            // МАГИЯТА
            Console.WriteLine(new string('*', n));
            for(var k=0;k<n-2;k++)
            Console.WriteLine('*'+new string(' ', n-2)+"*");
            Console.WriteLine(new string('*', n));
        }
    }
}

﻿using System;
namespace WholeNumberSign
{
    // 2. NumberCheck
    class Program
    {
        // Метод който проверява дали число е положително, отрицателно или нула
        static void NumberCheck(int num)
        {
            // Проверки
            if (num < 0) Console.WriteLine("The number {0} is negative.", num);
            if (num > 0) Console.WriteLine("The number {0} is positive.", num);
            if (num == 0) Console.WriteLine("The number 0 is zero.");
        }

        // Главен метод
        static void Main(string[] args)
        {
            var num = int.Parse(Console.ReadLine());
            NumberCheck(num);
        }
    }
}

﻿using System;
namespace EvenOddSumMultiplication
{
    // 8. EvenOddSumMultiplication
    class Program
    {

        // Сума на четните числа
        static double GetSumOfEvenDigits(int n)
        {
            double sum = 0;
            while (n > 0)
            {
                if ((n % 10) % 2 == 0) sum += n % 10; 
                n /= 10;
            }
            return sum;
        }
        // Сума на нечетни числа
        static double GetSumOfOddDigits(int n)
        {
            double sum = 0;
            while (n > 0)
            {
                if ((n % 10) % 2 != 0) sum += n % 10;
                n /= 10;
            }
            return sum;
        }
        // Умножение
        static double GetMultipleOfEvensAndOdds(int n)
        {
            return GetSumOfEvenDigits(n) * GetSumOfOddDigits(n);
        }
        // Главен метод на програмата
        static void Main(string[] args)
        {
            var n = Math.Abs(int.Parse(Console.ReadLine()));
            Console.WriteLine(GetMultipleOfEvensAndOdds(n));
        }
    }
}

﻿using System;
namespace TriangleArea
{
    // 5. TriangleArea
    class Program
    {
        // Метод за намиране на лице на триъгълник
        static double Area(double a, double ha)
        {
            return (a * ha) / 2;
        }

        // Главен метод
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var ha = double.Parse(Console.ReadLine());
            var s = Area(a, ha);
            Console.WriteLine(s);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrawFillRectangle
{
    // 4. DrawFillRectangle
    class Program
    {
        // Отпечатване на запълнен квадрат
        static void Print(int n)
        {
            Console.WriteLine(new string('-', n * 2));
            for (int i = 0; i <= n - 2; i++)
            {
                Console.Write("-");
                for (int j = 0; j <= (n - 2); j++)
                    Console.Write("\\/");
                Console.WriteLine("-");
            }
            Console.WriteLine(new string('-', n * 2));
        }
        // Главен метод
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            Print(n);
        }
    }
}

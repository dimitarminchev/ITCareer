﻿using System;
namespace PrintTriangle
{
    // 3. PrintTriangle
    class Program
    {
        // Метод за отпечатване на триъгълник по зададено число n
        static void Print(int n)
        {
            // First Part
            for (int k = 1; k <= n; k++)
            {
                for (int j = 1; j <= k; j++)
                    Console.Write("{0} ", j);
                Console.WriteLine();
            }
            // Second Part
            for (int k = n - 1; k > 0; k--)
            {
                for (int j = 1; j <= k; j++)
                    Console.Write("{0} ", j);
                Console.WriteLine();
            }
        }
        // Главен маетод
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            Print(n);
        }
    }
}

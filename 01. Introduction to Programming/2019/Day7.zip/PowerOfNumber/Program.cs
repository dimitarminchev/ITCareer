﻿using System;
namespace PowerOfNumber
{
    // 6. PowerOfNumber
    class Program
    {
        // Метод за повдигане на число на степен
        static double RaiseToPower(double number, int power)
        {
            double result = 1;
            for (int i = 0; i < power; i++)
                result *= number;
            return result;
        }

        // Главен метод
        static void Main(string[] args)
        {
            var number = double.Parse(Console.ReadLine());
            var power = int.Parse(Console.ReadLine());
            Console.WriteLine(RaiseToPower(number, power));
        }
    }
}

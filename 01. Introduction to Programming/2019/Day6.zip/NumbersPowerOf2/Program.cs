﻿using System;
namespace NumbersPowerOf2
{
    class Program
    {
        // 23. Числа – степени на 2 
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var num = 1;
            while (n > -1)
            {
                Console.WriteLine(num);
                num *= 2;
                n--;
            }
        }
    }
}

﻿using System;
namespace OrderOf2kPlus1
{
    class Program
    {
        // 25. Редица числа 2k+1
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var num = 1;
            while (num <= n)
            {
                Console.WriteLine(num);
                num = 2 * num + 1;
            }
        }
    }
}

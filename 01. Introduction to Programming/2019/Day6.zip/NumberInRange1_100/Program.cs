﻿using System;
namespace NumberInRange1_100
{
    class Program
    {
        // 26. Число в диапазона от 1 до 100
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var num = int.Parse(Console.ReadLine());
            while (num < 1 || num > 100)
            {
                Console.WriteLine("Invalid number!");
                num = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("The number is: {0}", num);
        }
    }
}

﻿using System;
namespace NumbersFromNto1
{
    class Program
    {
        // 22. Числата от N до 1 в обратен ред
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            for (int k = n; k > 0; k--)
            {
                Console.WriteLine(k);
            }
        }
    }
}

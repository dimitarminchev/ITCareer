﻿using System;
namespace EvenPowerOf2
{
    class Program
    {
        // 24. Четни степени на 2
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var num = 1;
            while (n > -1)
            {
                Console.WriteLine(num);
                num *= 4; 
                n-=2; 
            }
        }
    }
}

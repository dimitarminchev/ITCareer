﻿using System;
namespace LoopByStep3
{
    class Program
    {
        // 21. Числата от 1 до N през 3
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            Console.WriteLine("The numbers are:");
            for (int k = 1; k <= n; k+=3)
            {
                Console.WriteLine(k);
            }
        }
    }
}

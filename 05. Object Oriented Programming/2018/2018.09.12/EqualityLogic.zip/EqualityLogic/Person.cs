﻿using System;
using System.Collections.Generic;

namespace EqualityLogic {
    class Person : IComparable<Person> {
        public string Name { get; }
        public int Age { get; }

        public Person(string name, int age) {
            Name = name;
            Age = age;
        }

        public override bool Equals(object obj) =>
            obj is Person person &&
            Name == person.Name &&
            Age == person.Age;

        public override int GetHashCode() {
            var hashCode = -1360180430;
            hashCode *= -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            hashCode *= -1521134295 + Age.GetHashCode();
            return hashCode;
        }

        public int CompareTo(Person other) =>
            Name == other.Name && Age == other.Age ? 0 : Name != other.Name && Age == other.Age ? -1 : 1; 
    }
}

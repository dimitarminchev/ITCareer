﻿using System;
using System.Collections.Generic;

namespace EqualityLogic {
    class Program {
        static void Main(string[] args) {
            var num = int.Parse(Console.ReadLine());
            var hashset = new HashSet<Person>();
            var sortedset = new SortedSet<Person>();
            for (int i = 0; i < num; i++) {
                var input = Console.ReadLine().Split();
                var person = new Person(input[0], int.Parse(input[1]));
                hashset.Add(person);
                sortedset.Add(person);
            }
            Console.WriteLine(sortedset.Count + "\n" + hashset.Count);
        }
    }
}

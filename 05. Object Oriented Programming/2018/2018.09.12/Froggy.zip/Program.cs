﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        var rocks = Console.ReadLine()
                    .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse).ToArray();
        Lake lake = new Lake(rocks);
        Console.WriteLine(string.Join(", ", lake));
    }
}


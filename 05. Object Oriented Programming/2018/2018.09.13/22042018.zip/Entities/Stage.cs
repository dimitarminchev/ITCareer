﻿namespace FestivalManager.Entities
{
	using System.Collections.Generic;
	using Contracts;

	public class Stage : IStage
	{
		private readonly List<ISet> sets;
		private readonly List<ISong> songs;
		private readonly List<IPerformer> performers;

        public IReadOnlyCollection<ISet> Sets => sets;
        public IReadOnlyCollection<ISong> Songs => songs;
        public IReadOnlyCollection<IPerformer> Performers => performers;

        public Stage()
        {
            this.sets = new List<ISet>();
            this.songs = new List<ISong>();
            this.performers = new List<IPerformer>();
        }

        public IPerformer GetPerformer(string name)
        {
            if (this.HasPerformer(name))
                return this.performers.FindLast(x => x.Name == name);
            return null;
        }

        public ISong GetSong(string name)
        {
            if (this.HasSong(name))
                return this.songs.FindLast(x => x.Name == name);
            return null;
        }

        public ISet GetSet(string name)
        {
            if (this.HasSet(name))
                return this.sets.FindLast(x => x.Name == name);
            return null;
        }

        public void AddPerformer(IPerformer performer)
        {
            this.performers.Add(performer);
        }

        public void AddSong(ISong song)
        {
            this.songs.Add(song);
        }

        public void AddSet(ISet set)
        {
            this.sets.Add(set);
        }

        public bool HasPerformer(string name)
        {
            if (this.performers.Contains(performers.Find(x => x.Name == name)))
                return true;
            return false;
        }

        public bool HasSong(string name)
        {
            if (this.songs.Contains(songs.Find(x => x.Name == name)))
                return true;
            return false;
        }

        public bool HasSet(string name)
        {
            if (this.sets.Contains(sets.Find(x => x.Name == name)))
                return true;
            return false;
        }
    }
}

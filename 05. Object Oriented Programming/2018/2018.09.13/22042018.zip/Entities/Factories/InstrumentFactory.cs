﻿namespace FestivalManager.Entities.Factories
{
	using System;
	using System.Linq;
	using System.Reflection;
	using System.Runtime.InteropServices.WindowsRuntime;
	using Contracts;
	using Entities.Contracts;
	using Instruments;

	public class InstrumentFactory : IInstrumentFactory
	{
		public IInstrument CreateInstrument(string type)
		{
            var types = Assembly.GetCallingAssembly().GetTypes();
            var selectedType = types.Where(x => x.Name == type).ToArray().First();
            return (IInstrument)Activator.CreateInstance(selectedType);
        }
	}
}
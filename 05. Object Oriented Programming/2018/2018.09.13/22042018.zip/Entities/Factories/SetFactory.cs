﻿using System;

using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using FestivalManager.Entities.Sets;
using System.Linq;



namespace FestivalManager.Entities.Factories
{
	using Contracts;
	using Entities.Contracts;
	using Sets;

	public class SetFactory : ISetFactory
	{
		public ISet CreateSet(string name, string type)
		{
            var types = Assembly.GetCallingAssembly().GetTypes();
            var selectedType = types.Where(x => x.Name == type).ToArray().First();
            return (ISet)Activator.CreateInstance(selectedType, name);
        }
	}




}

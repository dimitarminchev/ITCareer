﻿using FestivalManager.Core.IO.Contracts;

namespace FestivalManager.Core.IO
{
	public class StringReader : IReader
	{
		private readonly System.IO.StringReader reader;

        public StringReader()
        {
        }

        public StringReader(string contents)
		{
			this.reader = new System.IO.StringReader(contents);
		}

        public string ReadLine() => System.Console.ReadLine();
	}
}
﻿using FestivalManager.Core.IO.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FestivalManager.Core.IO
{
    class StringWriter : IWriter
    {
        public void Write(string contents)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(contents);
            Console.ResetColor();
        }

        public void WriteLine(string contents)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(contents);
            Console.ResetColor();
        }
    }
}

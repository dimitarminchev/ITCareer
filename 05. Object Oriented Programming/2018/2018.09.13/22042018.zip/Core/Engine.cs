﻿
using System;
using System.Linq;
namespace FestivalManager.Core
{
    using System.Reflection;
	using Contracts;
	using Controllers;
	using Controllers.Contracts;
    using FestivalManager.Core.IO;
    using IO.Contracts;

	class Engine : IEngine
	{
	    private IReader reader;
	    private IWriter writer;

        private IFestivalController festivalController;
        private ISetController setController;

        public Engine(IFestivalController festivalController, ISetController setController)
        {
            this.reader = new StringReader();
            this.writer = new StringWriter();
            this.festivalController = festivalController;
            this.setController = setController;
        }

        // дайгаз
        public void Run()
		{
            var input = reader.ReadLine();
			while (input!="END")
			{
				try
				{
					//string.Intern(input);
					var result = this.ProcessCommand(input);
					this.writer.WriteLine(result);
				}
				catch (Exception ex) // in case we run out of memory
				{
					this.writer.WriteLine("ERROR: " + ex.InnerException.Message);
				}
                input = reader.ReadLine();
			}

            var end = this.festivalController.ProduceReport();

			this.writer.WriteLine("Results:");
			this.writer.WriteLine(end);
		}

		public string ProcessCommand(string input)
		{
			string[] parts = input.Split(" ".ToCharArray().First());
			string cmd = parts.First();
			string[] arg = parts.Skip(1).ToArray();

            if(cmd == "LetsRock")
            {
                var set = this.setController.PerformSets();
                return set;
            }

			var festivalcontrolfunction = this.festivalController.GetType()
				.GetMethods()
				.FirstOrDefault(x => x.Name == cmd);

			string a;

			try
			{
				a = (string)festivalcontrolfunction.Invoke(this.festivalController, new object[] { arg });
			}
			catch (TargetInvocationException up)
			{
				throw up; // ha ha
			}
			return a;
		}

    }
}
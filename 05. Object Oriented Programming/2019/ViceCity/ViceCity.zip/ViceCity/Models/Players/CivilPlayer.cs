﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViceCity.Models.Players
{
    public class CivilPlayer : Player
    {
        public CivilPlayer(string name) : base(name, 50)
        {
            ;;
        }
    }
}

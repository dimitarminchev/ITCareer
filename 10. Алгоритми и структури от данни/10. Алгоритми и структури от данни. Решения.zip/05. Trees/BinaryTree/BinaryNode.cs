﻿namespace BinaryTree
{
    // Единичен възел на двоичното дърво
    public class BinaryNode
    {
        public int Item;
        public BinaryNode Right;
        public BinaryNode Left;
        public BinaryNode(int item) { this.Item = item; }
    }
}

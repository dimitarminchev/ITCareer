﻿namespace FloatingPointNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            decimal a = 3.141592653589793238m;
            double b = 1.60217657d;
            decimal c = 7.8184261974584555216535342341m;
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
        }
    }
}
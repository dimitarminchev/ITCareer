﻿namespace CharacterReverse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string symbol1 = Console.ReadLine();
            string symbol2 = Console.ReadLine();
            string symbol3 = Console.ReadLine();
            Console.Write($"{symbol3}{symbol2}{symbol1}");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class Box<T> where T:IComparable<T>
    {
        private T ìtem;

        public T Item
        {
            get { return ìtem; }
            set { ìtem = value; }
        }

        public Box(T item = default(T))
        {
            this.Item = item;
        }

        
        public override string ToString()
        {
            return $"{Item.GetType().FullName}: {Item}";
        }
    }

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public static class Comparer
    {
        public static int Compare<T>(List<Box<T>> elements, Box<T> comparable) where T : IComparable<T>
        {
            int counter = 0;
            for (int i = 0; i < elements.Count(); i++)
            {
                if (elements[i].Item.CompareTo(comparable.Item) > 0)
                {
                    counter++;
                }
            }
            return counter;
        }
    }


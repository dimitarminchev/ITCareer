﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class Sorter
{
    public static CustomList<T> Sort<T>(CustomList<T> list) where T : IComparable<T>, IEnumerable
    {
        for (int i = 0; i < list.Items.Count - 1; i++)
        {
            for (int k = 0; k < list.Items.Count - i - 1; k++)
            {
                if (list.Items[k].CompareTo(list.Items[k + 1]) > 0)
                {
                    T temp = list.Items[k];
                    list.Items[k] = list.Items[k + 1];
                    list.Items[k + 1] = temp;
                }
            }
        }
        return list;
    }

}

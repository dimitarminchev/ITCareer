﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComparingObjects {
    class Program {
        static void Main(string[] args) {
            var list = new List<Tuple<string, int, string>>();
            string[] input;
            while ((input = Console.ReadLine().Split())[0] != "END")
                list.Add(new Tuple<string, int, string>(input[0], int.Parse(input[1]), input[2]));
            var selected = list[int.Parse(Console.ReadLine()) - 1];
            int count = list.Count(c => c.Item1 == selected.Item1 &&
            c.Item2 == selected.Item2 && c.Item3 == selected.Item3);
            Console.WriteLine(count != 1 ? $"{count} {list.Count - count} {list.Count}" : "No matches");
        }
    }
}

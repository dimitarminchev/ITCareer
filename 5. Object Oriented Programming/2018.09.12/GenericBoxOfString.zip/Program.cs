﻿using System;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Box<string>[] boxes = new Box<string>[n];

            for (int i = 0; i < n; i++)
            {
                boxes[i] = new Box<string>(Console.ReadLine());
            }

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }
    }
}

﻿namespace GenericBoxOfString
{
    class Box<T>
    {
        private T value;

        public T Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        public Box(T value)
        {
            this.value = value;
        }

        public override string ToString()
        {
            string returned = $"{value.GetType().FullName}: {this.value}";
            return returned;
        }
    }
}

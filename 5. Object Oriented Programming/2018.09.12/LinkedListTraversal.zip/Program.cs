﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        LinkedList<int> list = new LinkedList<int>();
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            var cmd = Console.ReadLine().Split().ToArray();
            switch (cmd[0])
            {
                case "Add":
                    {
                        list.Add(int.Parse(cmd[1]));
                        break;
                    }
                case "Remove":
                    {
                        list.Remove(int.Parse(cmd[1]));
                        break;
                    }
            }
        }
        Console.WriteLine(list.Count);
        Console.WriteLine(string.Join(" ", list));
    }
}


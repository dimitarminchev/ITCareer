﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericSwapMethodString
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Box<string>> strings = new List<Box<string>>();
            int n = int.Parse(Console.ReadLine());
            for(int i=1;i<=n;i++)
            {
                strings.Add(new Box<string>(Console.ReadLine()));
            }
            int[] indexes = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            Swapper.Swap(strings, indexes[0], indexes[1]);
            foreach(var item in strings)
            {
                Console.WriteLine(item);
            }
        }
    }
}

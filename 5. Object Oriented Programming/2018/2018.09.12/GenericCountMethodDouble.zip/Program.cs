﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    static void Main(string[] args)
    {
        //2.1
        //string[] strings = ArrayCreator.Create(5, "Pesho");
        //int[] integers = ArrayCreator.Create(10, 33);
        //foreach(var item in strings)
        //{
        //    Console.WriteLine(item);
        //}
        //Console.WriteLine();
        //foreach (var item in integers)
        //{
        //    Console.WriteLine(item);
        //}

        //2.2
        //int n = int.Parse(Console.ReadLine());
        //List<Box<string>> strings = new List<Box<string>>();

        //for(int i=1;i<=n;i++)
        //{
        //    strings.Add(new Box<string>(Console.ReadLine()));
        //}
        //int[] indexes = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
        //Swapper.SwapTwoValues(strings, indexes[0], indexes[1]);
        //foreach(var item in strings)
        //{
        //    Console.WriteLine(item);
        //}

        //2.3
        //int n = int.Parse(Console.ReadLine());
        //List<Box<int>> numbers = new List<Box<int>>();

        //for (int i = 1; i <= n; i++)
        //{
        //    numbers.Add(new Box<int>(int.Parse(Console.ReadLine())));
        //}
        //int[] indexes = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
        //Swapper.SwapTwoValues(numbers, indexes[0], indexes[1]);
        //foreach (var item in numbers)
        //{
        //    Console.WriteLine(item);
        //}

        //2.4
        //int n = int.Parse(Console.ReadLine());
        //List<Box<string>> strings = new List<Box<string>>();

        //for (int i = 1; i <= n; i++)
        //{
        //    strings.Add(new Box<string>(Console.ReadLine()));
        //}

        //Box<string> toCompare = new Box<string>(Console.ReadLine());

        //Console.WriteLine(Comparer.Compare(strings, toCompare));

        //2.5
        int n = int.Parse(Console.ReadLine());
        List<Box<double>> numbers = new List<Box<double>>();

        for (int i = 1; i <= n; i++)
        {
            numbers.Add(new Box<double>(double.Parse(Console.ReadLine())));
        }

        Box<double> toCompare = new Box<double>(double.Parse(Console.ReadLine()));

        Console.WriteLine(Comparer.Compare(numbers, toCompare));

    }
}

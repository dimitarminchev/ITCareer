﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class CustomList<T> : IEnumerable<T> where T : IComparable<T>
    {
        private List<T> items;
        public List<T> Items
        {
            get { return items; }
            set { items = value; }
        }

        public CustomList()
        {
            items = new List<T>();
        }
        public CustomList(List<T> items)
        {
            this.Items = items;
        }

        public void Add(T element)
        {
            items.Add(element);
        }
        public T Remove(int index)
        {
            T toReturn = items[index];
            items.RemoveAt(index);
            return toReturn;
        }
        public bool Contains(T element)
        {
            return items.Contains(element);
        }

        public void Swap(int index1, int index2)
        {
            T swap = items[index1];
            items[index1] = items[index2];
            items[index2] = swap;
        }

        public int CountGreaterThan(T element)
        {
            int counter = 0;
            for(int i=0;i<items.Count;i++)
            {
                if (items[i].CompareTo(element) > 0) counter++;
            }
            return counter;
        }

        public T Max()
        {
            T max = items[0];
            for(int i=0;i<items.Count;i++)
            {
                if(items[i].CompareTo(max) > 0)
                {
                    max = items[i];
                }
            }

            return max;
        }

        public T Min()
        {
            T min = items[0];
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].CompareTo(min) < 0)
                {
                    min = items[i];
                }
            }

            return min;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for(int i =0;i<items.Count;i++)
            {
                yield return items[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

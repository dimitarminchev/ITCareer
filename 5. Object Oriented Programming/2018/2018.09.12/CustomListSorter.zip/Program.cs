﻿using System;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        CustomList<string> strings = new CustomList<string>();
        string[] line = Console.ReadLine().Split(' ').ToArray();
        while (line[0] != "END")
        {
            switch (line[0])
            {
                case "Add":
                    strings.Add(line[1]);
                    break;
                case "Remove":
                    strings.Remove(int.Parse(line[1]));
                    break;
                case "Contains":
                    Console.WriteLine(strings.Contains(line[1]));
                    break;
                case "Swap":
                    strings.Swap(int.Parse(line[1]), int.Parse(line[2]));
                    break;
                case "Greater":
                    Console.WriteLine(strings.CountGreaterThan(line[1]));
                    break;
                case "Max":
                    Console.WriteLine(strings.Max());
                    break;
                case "Min":
                    Console.WriteLine(strings.Min());
                    break;
                case "Print":
                    for (int i = 0; i < strings.Items.Count; i++)
                    {
                        Console.WriteLine(strings.Items[i]);
                    }
                    break;
                case "Sort":
                    Sorter.Sort(strings);
                    break;
            }
            line = Console.ReadLine().Split(' ').ToArray();
        }
    }
}


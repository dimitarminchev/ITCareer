﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Stack<int> stack = new Stack<int>();
        var line = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
        while (line[0] != "END")
        {
            switch (line[0])
            {
                case "Push":
                    stack.Push(line.Skip(1).Select(int.Parse).ToArray());
                    break;
                case "Pop":
                    stack.Pop();
                    break;
            }
            line = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
        }
        // 2 x print
        foreach (var item in stack) Console.WriteLine(item);
        foreach (var item in stack) Console.WriteLine(item);
    }
}

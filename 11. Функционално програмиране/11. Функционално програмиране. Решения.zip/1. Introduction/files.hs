-- Files Haskell Program

-- File Path
filePath = "C:\\Users\\mitko\\Desktop\\files.txt"

-- Main
main = do

    -- Write
    writeFile filePath "This is one line of text wrtitten in file.\n"

    -- Append
    appendFile filePath "This is second line of thext in the file."

    -- Read
    file <- readFile filePath
    putStrLn file
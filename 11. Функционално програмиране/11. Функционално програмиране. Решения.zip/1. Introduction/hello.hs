--  Hello Haskell Program
main = do

    -- Print "Hello World" on the screen
    putStrLn "Hello World"
-- Introduction Haskell Program

-- Func -> String
dummyGetLine = 
    return "Please enter yor name: "

-- Main
main = do

    -- Execute func: dummyGetLine
    dummy <- dummyGetLine
    putStrLn dummy

    -- Read a line from console
    line <- getLine 

    -- Print the string
    putStrLn ("Echo: " ++ line)
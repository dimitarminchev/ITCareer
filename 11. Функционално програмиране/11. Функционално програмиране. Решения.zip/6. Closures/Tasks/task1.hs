-- Зад. 1 Умножение на числа
add x = (\y -> x * y)

main = do

      putStrLn(show(add 5 10)) -- 50
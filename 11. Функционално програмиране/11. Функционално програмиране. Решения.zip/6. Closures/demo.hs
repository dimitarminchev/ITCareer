
f x = (\y -> x + y)

main = do
      
      putStrLn(show(f 2 3)) -- 5
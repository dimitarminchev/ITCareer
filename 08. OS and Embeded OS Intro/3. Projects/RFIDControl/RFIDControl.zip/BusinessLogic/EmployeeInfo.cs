﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1.BusinessLogic
{
    class EmployeeInfo
    {
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string LastName { get; set; }
        public string EGN { get; set; }
        public string Duty { get; set; }
        public string Town { get; set; }
        public string TelephoneNumber { get; set; }
        public string ScannerCardNumber { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace App1.Models
{
    public partial class Lastscaned
    {
        public int Id { get; set; }
        public string ScannerCardNumber { get; set; }
    }
}

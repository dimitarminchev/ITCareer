﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainsSkeleton
{
    class Deque<T>
    {
        private T[] frontBuffer = new T[100];
        private T[] backBuffer = new T[100];

        public int BackCount { get; private set; }
        public int FrontCount { get; private set; }
        public int Count
        {
            get
            {
                return BackCount + FrontCount;
            }
        }
        
        public void AddBack(T item)
        {
            if (this.BackCount == this.backBuffer.Length)
            {
                GrowBack();
            }
            
            backBuffer[this.BackCount] = item;
            this.BackCount++;
        
        }

        private void GrowBack()
        {
            throw new NotImplementedException();
        }

        public void AddFront(T item)
        {
            if (this.FrontCount == this.frontBuffer.Length)
            {
                GrowFront();
            }
            frontBuffer[this.FrontCount] = item;
            this.FrontCount++;
        
        }
        private void GrowFront()
        {
            throw new NotImplementedException();
        }

        public T GetFront()
        {
            if (this.FrontCount == 0)
            {
                return default(T);
            }
            T element = this.frontBuffer[this.FrontCount - 1];
            return element;
        }

        public T GetBack()
        {

            if (this.BackCount == 0)
            {
                return default(T);
            }
            T element = this.backBuffer[this.BackCount - 1];
            return element;
        }

        public T RemoveBack()
        {
            if (this.BackCount == 0)
            {
                return default(T);
            }
            T element = this.backBuffer[this.BackCount - 1];
            this.BackCount--;
            //todo: add shrink method
            return element;
        }

        public T RemoveFront()
        {
            if (this.FrontCount == 0)
            {
                return default(T);
            }
            T element = this.frontBuffer[this.FrontCount - 1];
            this.FrontCount--;
            //todo: add shrink method
            return element;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _423
{
    class Program
    {
        // Автор: Христо Широв
        static void Main(string[] args)
        {
            int[] arr = { 5, 8, -1, 32, 18};
            Sort.Insertion<int>(arr);
        }
    }
}

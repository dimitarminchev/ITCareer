﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _411
{
    class Program
    {
        // Автор: Владислав Петков
        static void Main(string[] args)
        {
            // Look 412
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _436
{
    class Program
    {
        // Автор: Димитър Митев
        static void Main(string[] args)
        {
        }
    }
}

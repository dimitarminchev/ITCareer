﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _433
{
    class Program
    {
        // Автор: Щерю Атанасов
        static void Main(string[] args)
        {
        }
    }
}

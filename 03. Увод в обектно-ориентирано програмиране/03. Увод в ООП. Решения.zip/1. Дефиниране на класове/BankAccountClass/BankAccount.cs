﻿namespace BankAccountClass
{
    class BankAccount
    {
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        private double balance;

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
    }
}
﻿namespace GrandPrix
{
    public class Reader
    {
        public virtual string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}

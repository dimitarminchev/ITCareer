﻿namespace RectanglesOverlap
{
    class Rectangle
    {
        private string id;
        public string ID
        {
            get { return id; }
            set { id = value; }
        }

        private int width;
        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        private int heigh;
        public int Heigh
        {
            get { return heigh; }
            set { heigh = value; }
        }

        private int horizontally;
        public int Horizontally
        {
            get { return horizontally; }
            set { horizontally = value; }
        }

        private int vertically;
        public int Vertically
        {
            get { return vertically; }
            set { vertically = value; }
        }
    }
}

﻿namespace PokemonTrainer
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO
        }
    }
}
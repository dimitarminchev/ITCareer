Тестовете на упражненията са налични в Интернет на адрес:
https://judge.softuni.bg/Contests/#!/List/ByCategory/42/CSharp-OOP-Basics

﻿namespace Numbers1to100
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine("i=" + i);
            }
        }
    }
}
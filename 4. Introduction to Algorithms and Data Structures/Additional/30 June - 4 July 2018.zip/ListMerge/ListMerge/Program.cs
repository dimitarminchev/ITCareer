﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMerge
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list1 = Console.ReadLine().Split(' ')
                .Select(int.Parse).ToList();
            List<int> list2 = Console.ReadLine().Split(' ')
                            .Select(int.Parse).ToList();

            List<int> mergedList = new List<int>();
            int index1 = 0, index2 = 0;
            while (index1 < list1.Count || index2 < list2.Count)
            {
                if (index1 >= list1.Count)
                {
                    mergedList.Add(list2[index2]);
                    index2++;
                    continue;
                }
                if (index2 >= list2.Count)
                {
                    mergedList.Add(list1[index1]);
                    index1++;
                    continue;
                }
                if (list1[index1] <= list2[index2])
                {
                    mergedList.Add(list1[index1]);
                    index1++;
                }
                else
                {
                    mergedList.Add(list2[index2]);
                    index2++;
                }
            }

            Console.WriteLine(String.Join(" ", mergedList));

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Undo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<String> history = new Stack<string>();
            string[] command;
            do
            {
                command = Console.ReadLine().Split(' ').ToArray();
                switch(command[0]){
                    case "Add":
                        history.Push(command[1]);
                        break;
                    case "Back":
                        try
                        {
                            Console.WriteLine(history.Pop());
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            
                        }
                        break;
                }

            } while (command[0] != "End");
        }
    }
}

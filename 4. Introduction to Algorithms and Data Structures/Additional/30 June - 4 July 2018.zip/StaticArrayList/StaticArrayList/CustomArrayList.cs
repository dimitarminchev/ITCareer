﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticArrayList
{
    public class CustomArrayList
    {
        private object[] arr;

        private int count;

        public int Count
        {
            get
            {
                return count;
            }
        }

        private static readonly int INITIAL_CAPACITY = 4;

        public CustomArrayList()
        {
            arr = new object[INITIAL_CAPACITY];
            count = 0;
        }

        public void Add(object item)
        {
            Insert(count, item);
        }

        public void Insert(int index, object item)
        {
            if (index > count || index < 0)
            {
                throw new IndexOutOfRangeException();
            }

            object[] newArr = arr;
            if (count == arr.Length - 1)
            {
                newArr = new object[arr.Length * 2];
            }
            Array.Copy(arr, newArr, index);
            count++;
            Array.Copy(arr, index, newArr, index + 1, count
               - index - 1);
            newArr[index] = item;
            arr = newArr;
        }

        public int IndexOf(object item)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (item==arr[i])
                {
                    return i;
                }
            }

            return -1;
        }

        public void Clear()
        {
            arr = new object[INITIAL_CAPACITY];
            count = 0;
        }

        public bool Contains(object item)
        {
            int index = IndexOf(item);
            bool found = (index != -1);
            return found;
        }

        public object this[int index]
        {
            get
            {
                if (index >= count || index < 0)
                {
                    throw new ArgumentOutOfRangeException();
                }

                return arr[index];
            }

            set
            {
                if (index >= count || index < 0)
                {
                    throw new ArgumentOutOfRangeException();
                }

                arr[index] = value;
            }
        }

        public object Remove(int index)
        {
            if (index >= count || index < 0)
            {
                throw new IndexOutOfRangeException();
            }

            object item = arr[index];
            Array.Copy(arr, index + 1, arr, index, count - index - 1);
            arr[count - 1] = null;
            count--;
            return item;
        }

        public object Remove(object item)
        {
            int index = IndexOf(item);
            if (index==-1)
            {
                return -1;
            }

            return Remove(index);
        }

        public string Print()
        {
            return String.Join(" ", arr);
        }
    }

}

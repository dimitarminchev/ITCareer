﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomArrayList shoppingList
                = new CustomArrayList();
            shoppingList.Add("Water");
            shoppingList.Add("Meat");
            shoppingList.Add("Cucumber");
            shoppingList.Add("Tomato");
            shoppingList.Add("Cabbage");
            for (int i = 0; i < shoppingList.Count; i++)
            {
                Console.WriteLine(shoppingList[i]);
            }

            Console.WriteLine(shoppingList.IndexOf("Milk"));
            shoppingList.Remove(2);
            Console.WriteLine(shoppingList.Print()); 

        }
    }
}

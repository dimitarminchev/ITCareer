﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Union
{
    class Program
    {
        static List<int> Union(List<int> firstList,
            List<int> secondList)
        {
            List<int> union = new List<int>();
            union.AddRange(firstList);
            foreach (var item in secondList)
            {
                if (!union.Contains(item))
                {
                    union.Add(item);
                }
            }

            return union;
        }

        static List<int> Intersect(List<int> firstList,
                    List<int> secondList)
        {
            List<int> intersect = new List<int>();
            
            foreach (var item in firstList)
            {
                if (secondList.Contains(item))
                {
                    intersect.Add(item);
                }
            }

            return intersect;
        }

        static string PrintList(List<int> list)
        {
            return String.Join(" ", list);
        }

        static void Main(string[] args)
        {
            List<int> firstList = Console.ReadLine()
                .Split(' ').Select(int.Parse).ToList();
            List<int> secondList = Console.ReadLine()
                .Split(' ').Select(int.Parse).ToList();
            List<int> unionList = Union(firstList, secondList);
            List<int> intersectList
                = Intersect(firstList, secondList);
            Console.WriteLine(PrintList(unionList));
            Console.WriteLine(PrintList(intersectList));

        }
    }
}

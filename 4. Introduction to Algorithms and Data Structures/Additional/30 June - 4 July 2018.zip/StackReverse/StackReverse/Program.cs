﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackReverse
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> s = new Stack<int>();
            int[] nums = Console.ReadLine()
                .Split(' ').Select(int.Parse)
                .ToArray();
            foreach (var num in nums)
            {
                s.Push(num);
            }

            while (s.Count != 0)
            {
                Console.Write(s.Pop()+" ");
            }
        }
    }
}

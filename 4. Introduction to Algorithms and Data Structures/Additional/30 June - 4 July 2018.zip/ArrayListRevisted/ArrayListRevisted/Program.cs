﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListRevisted
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arr = new ArrayList(3);
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(' ').ToArray();
                switch (command[0])
                {
                    case "Add":
                        arr.Add(int.Parse(command[1]));
                        break;
                    case "Get":
                        Console.WriteLine(
                            arr[int.Parse(command[1])]
                        );
                        break;
                    case "Set":
                        // command[1] - index, command[2] - value
                        int index = int.Parse(command[1]);
                        int value = int.Parse(command[2]);
                        
                        arr[index] = value;

                        break;
                    case "Print":
                        Console.WriteLine(arr.Print());
                        break;
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListRevisted
{
    class ArrayList
    {
        private int[] items;
        public int Count { get; private set; }
        private const int InitialCapacity = 16;

        private int nextIndex = 0;
        private int nextAggrateIndex = 0;

        public ArrayList(int capacity = InitialCapacity)
        {
            items = new int[capacity];
            Count = 0;
        }

        public int this[int index] {
            get
            {
                if (index >= items.Length || index < 0)
                {
                    throw new ArgumentOutOfRangeException();
                }
                return items[index];
            }

            set
            {
                if (index >= items.Length || index < 0)
                {
                    throw new ArgumentOutOfRangeException();
                }

                items[index] = value;
            }
        }

        public int Sum()
        {
            int sum = 0;
            for (int i = 0; i < items.Length; i++)
            {
                Console.WriteLine(items[i]);
                sum += items[i];
            }

            return sum;
        }
        public void Add(int item) {
            if (nextIndex == items.Length
                && nextAggrateIndex<items.Length)
            {
                items[nextAggrateIndex++] = Sum();
                Count = nextAggrateIndex;
                nextIndex = Count;
            }

            if (nextIndex < items.Length)
            {
                items[nextIndex++] = item;
            }
        }
        public int Get(int index) {
            return this[index];
        }
        public void Set(int index, int item) {
            this[index] = item;
        }

        public string Print()
        {
            return String.Join(" ", items);
        }
    }
}

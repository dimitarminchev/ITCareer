﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReversedList
{
    class ReversedList<T> : IEnumerable<T>
    {
        private int DefaultCapacity = 2;
        private T[] items;
        private T[] itemsSorted;
        private bool changed = false;
        public int Count { get; private set; }
        public int Capacity { get; private set; }

        public ReversedList()
        {
            Capacity = DefaultCapacity;
            this.items = new T[Capacity];
        }

        public T this[int index]
        {
            get
            {
                CheckIndex(index);
                return this.items[this.Count - 1 - index];
            }
            set
            {
                CheckIndex(index);
                this.items[this.Count - 1 - index] = value;
            }
        }

        private void CheckIndex(int index){
            if(index<0 || index > Count){
                throw new IndexOutOfRangeException();
            }
        }

        public void Add(T element)
        {
            if (Count == this.items.Length)
            {
                Grow();
            }

            this.items[this.Count++] = element;
            changed = true;
        }

        private void Grow()
        {
            Capacity*=2;
            T[] newArr = new T[Capacity];
            Array.Copy(this.items, newArr, this.items.Length);
            items = newArr;
        }

        public T[] GetReversed()
        {
            if (changed)
            {
                this.itemsSorted = this.items
                    .Take(this.Count).Reverse().ToArray();
            }
            
            return this.itemsSorted;
        }

        public T GetReversedByIndex(int index)
        {
            CheckIndex(index);
            return GetReversed()[index];
        }

        public T RemoveAt(int index)
        {
            CheckIndex(index);
            T element = this.items[this.Count - 1 - index];
            items = items.Take(this.Count - 1 - index)
                .Concat(items.Skip(this.Count - index))
                .ToArray();
            this.Count--;
            changed = true;
            return element;
        }

        public IEnumerator<T> GetEnumerator()
        {
            T[] currentItems = GetReversed();
            for (int i = 0; i < this.Count; i++)
            {
                yield return currentItems[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}

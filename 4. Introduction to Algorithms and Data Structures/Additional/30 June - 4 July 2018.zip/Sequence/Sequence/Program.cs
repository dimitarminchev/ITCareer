﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sequence
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = Console.ReadLine()
                .Split(' ').Select(int.Parse)
                .ToList();
            int listCount = list.Count;
            int currVal = list[0];
            int currCount = 1;
            int maxVal = currVal;
            int maxCount = 1;
            for (int i = 1; i < listCount; i++)
            {
                if (list[i] == currVal)
                {
                    currCount++;
                    if (currCount > maxCount)
                    {
                        maxCount = currCount;
                        maxVal = currVal;
                    }
                }
                else
                {
                    if (currCount > maxCount)
                    {
                        maxCount = currCount;
                        maxVal = currVal;
                    }
                    currCount = 1;
                    currVal = list[i];
                }    
            }
            Console.WriteLine("{0} {1} times", maxVal,
                maxCount);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int p = int.Parse(Console.ReadLine());
            Queue<int> q = new Queue<int>();
            q.Enqueue(n);
            int index = 0;
            int current, prev;
            while (q.Count > 0)
            {
                current = q.Dequeue();
                prev = current;
                index++;
                if (current == p)
                {
                    Console.WriteLine(index);
                    break;
                }

                if (p < current && p < prev)
                {
                    Console.WriteLine(p + " is not found!");
                    break;
                }
                q.Enqueue(current + 1);
                q.Enqueue(current * 2);
            }
        }
    }
}

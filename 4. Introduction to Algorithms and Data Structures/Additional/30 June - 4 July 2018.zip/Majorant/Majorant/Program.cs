﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Majorant
{
    class Program
    {
        static void Main(string[] args)
        {
            Majorant m = new Majorant(1000);
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int num = int.Parse(Console.ReadLine());
                try {
                    m.Add(num);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            try {
                Console.WriteLine(m.GetMajorant());
            }catch(Exception vaflichka) {
                Console.WriteLine(vaflichka.Message);
            }
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Majorant
{
    class Majorant
    {
        private int[] counts;
        public int Count { get; private set;}

        public Majorant(int maxNumber)
        {
            counts = new int[maxNumber + 1];
        }

        public void Add(int num)
        {
            if (num >= counts.Length || num < 0)
            {
                throw new Exception("Not supported number!");
            }
            counts[num]++;
            Count++;
        }

        public int GetMajorant()
        {
            for (int i = 0; i < counts.Length; i++)
            {
                if (counts[i] >= (Count / 2 + 1))
                {
                    return i;
                }
            }

            throw new Exception("The majorant does not exist!");
        }

    }
}

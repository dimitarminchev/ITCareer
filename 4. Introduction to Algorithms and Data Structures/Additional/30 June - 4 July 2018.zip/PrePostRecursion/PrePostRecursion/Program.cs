﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrePostRecursion
{
    class Program
    {
        static void PrintShape(int n)
        {
            if (n == 0)
            {
                return;
            }
            Console.WriteLine(new string('*', n));
            PrintShape(n - 1);
            Console.WriteLine(new string('#', n));
        }
        static void Main(string[] args)
        {
            PrintShape(5);
        }
    }
}

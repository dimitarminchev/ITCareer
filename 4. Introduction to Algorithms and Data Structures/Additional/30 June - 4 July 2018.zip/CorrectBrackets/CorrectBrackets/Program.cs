﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrectBrackets
{
    class Program
    {
        static bool IsCorrect(string expression)
        {
            Stack<int> stack = new Stack<int>();
            bool correctBrackets = true;
            for (int i = 0; i < expression.Length; i++)
            {
                char ch = expression[i];
                if (ch == '(')
                {
                    stack.Push(i);
                }
                else if (ch == ')')
                {
                    if (stack.Count == 0)
                    {
                        correctBrackets = false;
                        break;
                    }
                    stack.Pop();
                }
            }

            if (stack.Count != 0)
            {
                correctBrackets = false;
            }

            return correctBrackets;
        }
        static void Main(string[] args)
        {
            string expression = Console.ReadLine();
            if (IsCorrect(expression))
            {
                Stack<int> stack = new Stack<int>();
                for (int i = 0; i < expression.Length; i++)
                {
                    char ch = expression[i];
                    if (ch == '(')
                    {
                        stack.Push(i);
                    }
                    else if (ch == ')')
                    {
                        int startIndex = stack.Pop();
                        int length = i - startIndex + 1;
                        string contents 
                            = expression.Substring(startIndex, length);
                        Console.WriteLine(contents);
                    }
                }
            }
            else
            {
                Console.WriteLine("Invalid expression!");
            }            
        }
    }
}

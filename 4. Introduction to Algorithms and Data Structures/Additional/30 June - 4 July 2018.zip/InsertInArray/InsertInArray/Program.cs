﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsertInArray
{
    class Program
    {
        static void PrintArray(int[] arr)
        {
            foreach (var item in arr)
            {
                Console.Write(item+", ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse)
                .ToArray();
            Console.WriteLine("Before: ");
            PrintArray(arr);
            // ако работим върху несортиран масив: arr = arr.OrderBy(element => element).ToArray();
            int num = int.Parse(Console.ReadLine());
            bool inserted = false;
            for (int i = 0; i < arr.Length -1; i++)
            {
                if (num > arr[i] && num <= arr[i + 1])
                {
                    int[] newArr = new int[arr.Length+1];
                    int index = 0;
                    //може да се ползват и array copy методите!!!
                    for (int j = 0; j <= i; j++)
                    {
                        newArr[index++] = arr[j];
                    }
                    newArr[index++] = num;
                    inserted = true;
                    for (int j = i + 1; j < arr.Length; j++)
                    {
                        newArr[index++] = arr[j];
                    }
                    arr = newArr;
                }
            }

            if (!inserted)
            {
                if (num <= arr[0])
                {
                    //insert at the beginning
                    int[] newArr = new int[arr.Length + 1];
                    int index = 0;
                    newArr[index++] = num;
                    for (int i = 0; i < arr.Length; i++)
                    {
                        newArr[index++] = arr[i];
                    }
                    arr = newArr;
                }
                else if (num >= arr[arr.Length - 1])
                {
                    //insert at the end
                    int[] newArr = new int[arr.Length + 1];
                    int index = 0;
                    for (int i = 0; i < arr.Length; i++)
                    {
                        newArr[index++] = arr[i];
                    }
                    newArr[index++] = num;

                    arr = newArr;
                }
            }

            Console.WriteLine("After: ");
            PrintArray(arr);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxSubSequence
{
    class Program
    {
        static List<int> MaxSubSequence(List<int> list)
        {
            List<int> maxSubSequence = new List<int>();
            List<int> tmpSubSequence = new List<int>();
            maxSubSequence.Add(list[0]);
            int i = 1;
            do
            {
                tmpSubSequence.Add(list[i - 1]);
                while (i < list.Count && list[i - 1] < list[i])
                {
                    tmpSubSequence.Add(list[i++]);
                }

                if (maxSubSequence.Count < tmpSubSequence.Count)
                {
                    maxSubSequence.Clear();
                    maxSubSequence.AddRange(tmpSubSequence);
                }
                tmpSubSequence.Clear();
                i++;
            } while (i < list.Count);

            return maxSubSequence;
        }
        static void Main(string[] args)
        {
        }
    }
}

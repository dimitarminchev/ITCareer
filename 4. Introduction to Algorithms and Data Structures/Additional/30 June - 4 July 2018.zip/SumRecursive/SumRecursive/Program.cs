﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumRecursive
{
    class Program
    {
        static int Sum(int[] arr, int index)
        {
            if (index == arr.Length - 1)
            {
                return arr[index];
            }

            return arr[index] + Sum(arr, index + 1);
        }

        static void Main(string[] args)
        {

            int[] arr = Console.ReadLine()
                .Split(' ').Select(int.Parse)
                .ToArray();
            String result = String.Join("+", arr);
            Console.WriteLine(result+"="+Sum(arr, 0));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearch
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split(' ')
                .Select(int.Parse).ToArray();
            int x = int.Parse(Console.ReadLine());
            int left = 0, right = arr.Length - 1, mid = -1;
            int index = -1;
            while (right >= left)
            {
                mid = left + (right - left) / 2;
                if (arr[mid] == x)
                {
                    index = mid;
                    break;
                }
                else if (arr[mid] > x)
                {
                    right = mid - 1;
                }
                else if (arr[mid] < x)
                {
                    left = mid + 1;
                }
            }

            int[] newArr = new int[arr.Length + 1];
            if (arr[mid] == x)
            {
                //добавяме на mid+1 и отместваме
                Array.Copy(arr, 0, newArr, 0, mid + 1);
                newArr[mid + 1] = x;
                Array.Copy(arr, mid + 1, newArr, mid + 2, arr.Length - mid - 1);
                arr = newArr;
                Console.WriteLine(String.Join(",", arr));
            }
            else if (arr[mid] < x)
            {
                Array.Copy(arr, 0, newArr, 0, mid + 1);
                newArr[mid + 1] = x;
                Array.Copy(arr, mid + 1, newArr, mid + 2, arr.Length - mid - 1);
                arr = newArr;
                Console.WriteLine(String.Join(",", arr));
            }
            else if (arr[mid] > x)
            {
                Array.Copy(arr, 0, newArr, 0, mid);
                newArr[mid] = x;
                for (int i = mid; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);
                }
                Array.Copy(arr, mid, newArr, mid+1, arr.Length - mid);
                arr = newArr;
                Console.WriteLine(String.Join(",", arr));
            }

        }
    }
}

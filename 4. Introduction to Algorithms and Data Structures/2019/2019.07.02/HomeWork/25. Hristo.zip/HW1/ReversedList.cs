﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1
{
    class ReversedList<T> //: IEnumerable<T>
    {
        private T[] elements;
        private const int Default_Capacity = 2;
        public int Count { get; private set; }
        public int Capacity { get; private set; }

        public ReversedList()
        {
            Capacity = Default_Capacity;
            this.elements = new T[Capacity];
        }

        public T this[int index]
        {
            get { return elements[Capacity - Count + index]; }
            set { elements[index] = value; }
        }

        public void Add(T item)
        {
            if(Count == Capacity)
            {
                Resize();
            }

            elements[Capacity - Count] = item;
        }

        public T RemoveAt(int index)
        {
            T element = this.elements[Capacity - Count + index];
            elements[Capacity - Count + index] = default(T);
            this.Shift(index);
            this.Count--;

            if(this.Count <= this.elements.Length / 4)
            {
                this.Shrink();
            }

            return element;
        }

        private void Shift(int index)
        {
            for (int i = 0; i < Count; i++)
            {
                this.elements[i] = this.elements[i + 1];
            }
        }

        private void Shrink()
        {
            T[] copy = new T[this.elements.Length / 2];
            for (int i = 0; i < this.Count; i++)
            {
                copy[i] = this.elements[i];
            }

            this.elements = copy;
        }

        private void Resize()
        {
            T[] copy = new T[Capacity * 2];
            for (int i = 0; i < elements.Length; i++)
            {
                copy[i] = elements[i];
            }

            elements = copy;
        }

        //TODO IEnumerable
    }
}

/*
Задача 3.21. Всички символи Diablo
Изведете всички символи в азбучен ред . Изпратете вашите заявки като Подготвите БД & изпълните заявките (Prepare DB & run queries.)
*/
SELECT `Name`
FROM `diablo`.`characters`
ORDER BY `Name`;
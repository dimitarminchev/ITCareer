﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// MySQL
using MySql.Data;
using MySql.Data.MySqlClient;

namespace MySQL_Amazing_Mega_App
{
    class Program
    {
        // Demo
        static void Main(string[] args)
        {
            // Connection String
            string connstr = "server=localhost;user=root;database=soft_uni;port=3306;password=root";

            // MySQL Connection
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                // Open MySQL Connection
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                // SQL
                string sql = "SELECT * FROM employees";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                // MySQL Reader
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine("#{0} = {1} {2}",reader[0],reader[1], reader[2]);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");

        }
    }
}

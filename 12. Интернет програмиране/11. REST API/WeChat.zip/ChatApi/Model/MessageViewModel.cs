﻿namespace ChatApi.Model
{
    public class MessageViewModel
    {
        public string Content { get; set; }

        public string User { get; set; }
    }
}

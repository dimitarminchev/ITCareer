﻿using Microsoft.EntityFrameworkCore;

namespace Data
{
    public class CatContext : DbContext
    {
        public virtual DbSet<Cat> Cats { get; set; }

        public CatContext()
        {
            ;;
        }

        public CatContext(DbContextOptions<CatContext> options) : base(options)
        {
            ;;
        }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CatsDatabase;");
            optionBuilder.UseLazyLoadingProxies();
        }
    }
}

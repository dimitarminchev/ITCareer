# FDMC

## 1. Class Library (.NET Core)
Create **Class Library (.NET Core)** Project and Named it **Data**.

Add NuGet Packages
```
Microsoft.EntityFrameworkCore
Microsoft.EntityFrameworkCore.Design
Microsoft.EntityFrameworkCore.Proxies
Microsoft.EntityFrameworkCore.SqlServer
Microsoft.EntityFrameworkCore.Tools
```

Add Class Cat
```cs
public class Cat
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public string Breed { get; set; }
    public string Image { get; set; }
}
```

Add Class CatContext
```cs
public class CatContext : DbContext
{
    public virtual DbSet<Cat> Cats { get; set; }

    public CatContext()
    {
        ;;
    }

    public CatContext(DbContextOptions<CatContext> options) : base(options)
    {
        ;;
    }
    
    protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
    {
        optionBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CatsDatabase;");
        optionBuilder.UseLazyLoadingProxies();
    }
}
```

Package Manager Console
```
Add-Migration InitialCreate
Update-Database
```

## 2. ASP.NET Core Web Application

Create **ASP.NET Core Web Application** Project using the template **Web Application (Model-View-Controller)** and Named it **Web**.

* Add reference to the project **Data**.
* Add folder **Cats** in the Views.
* Right Click on Cats: Add > New Scafolded Item > MVC Controller with Views, using Entity Framework

```
Model: Cat
Data content class: CatContext (Data)
```
Move **CatsController.cs** to the folder Controllers

appsettings.json
```cs
"ConnectionStrings": {
    "DefaultConnection": "Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CatsDatabase;"
}
```

StartUp.cs Add
```cs
builder.Services.AddDbContext<Data.CatContext>(option =>
        option.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
```

\_Layout.cshtml
```html
<li class="nav-item">
    <a class="nav-link text-dark" asp-area="" asp-controller="Cats" asp-action="Index">Cats</a>
</li>
```
